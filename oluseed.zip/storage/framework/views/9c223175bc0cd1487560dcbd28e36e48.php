<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="theme-color" content="#0a0a14" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta
      name="description"
      content="Oluseed Technologies: ignition, development and advancement. We design and engineer websites, apps and digital products with professionalism."
    />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <title><?php echo e(config('app.name', 'Oluseed Technologies')); ?></title>
    <style>
      html { background: #0a0a14; }
    </style>
    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/main.tsx']); ?>
  </head>
  <body>
    <div id="root"></div>
  </body>
</html>
<?php /**PATH C:\Users\USER\Documents\project\Web App\oluseed\oluseed\resources\views/app.blade.php ENDPATH**/ ?>